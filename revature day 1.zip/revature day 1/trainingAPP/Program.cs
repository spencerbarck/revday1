﻿using System;

namespace trainingAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Goodbuy Cruel World!");
        }
    }
}
